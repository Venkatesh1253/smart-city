/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author iiit
 */
public class colleges extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
        
         Class.forName("com.mysql.cj.jdbc.Driver");
      Connection con =(Connection)java.sql.DriverManager.getConnection("jdbc:mysql://localhost:3306/se_project","root","iiits123");
      Statement st1=con.createStatement();
      String stu_name=request.getParameter("stu_name");
        String stu_father=request.getParameter("stu_father");
        String stu_dob=request.getParameter("stu_dob");
        String stu_class=request.getParameter("stu_class");
        String stu_school=request.getParameter("stu_college");
        String stu_email=request.getParameter("stu_email");
        
      String query="select count(*) from colleges where stu_email='"+stu_email+"';";
      ResultSet res1=st1.executeQuery(query);
     res1.next();
     int status=0;
     int count=0;
     count=res1.getInt(1);
     if(count==0){
         String query1="insert into colleges values('"+stu_name+"','"+stu_father+"','"+stu_email+"','"+stu_dob+"','"+stu_class+"','"+stu_school+"');";
         status=st1.executeUpdate(query1);
     }
     else{
         
     }
     
     
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet colleges</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<body style=\"background-image: linear-gradient(rgba(12,3,51,0.3),rgba(12,3,51,0.3));\" >");
             
            if (count!=0){
                out.println("<div style=\"background-color:green; height:100px;\">");
                out.println("<h1 style=\"margin-top:200px; margin-left:250px; color:white;\" >Student is  already in the school.Go back</h1> <form action=\"education.html\" ><button type=\"submit\" style=\"height:30px; width:100px; margin-left:500px;\" >Return</button>");
                out.println("</div>");
            }
            if(count==0){
             
             out.println("<div style=\" margin-left:350px;   height:20px; width:500px; \">");
             out.println("<hr style=\"margin-top:100px; color:green; height:10px;  \">");
             out.println("<h2 style=\"color:blue; margin-left:50px;\" ><b>Student Name</b>:  <small style=\"color:black;\" >"+stu_name+"</small></h2>");
             out.println("<h2 style=\"color:blue; margin-left:50px;\" ><b>Student Father</b>: <small style=\"color:black;\" >"+stu_father+"</small></h2>");
             out.println("<h2 style=\"color:blue; margin-left:50px;\" ><b>Student email</b>:  <small style=\"color:black;\" >"+stu_email+"</small></h2>");
             out.println("<h2 style=\"color:blue; margin-left:50px;\" ><b>Student Date of birth</b>:  <small style=\"color:black;\" >"+stu_dob+"</small></h2>");
             out.println("<h2 style=\"color:blue; margin-left:50px;\" ><b>Student Class</b>:  <small style=\"color:black;\" >"+stu_class+"</small></h2>");
             out.println("<h2 style=\"color:blue; margin-left:30px;\" ><b>Student year or branch</b>:  <small style=\"color:black;\" >"+stu_school+"</small></h2>");
             out.println("<h4>you are registered for the college.Take the screenshot and come to the college for complete the full admmission....");
            out.println("<br>");
             
             out.println(" <a style=\" margin-left:200px; \" href='hospitals.html'><button style=\"height:30px;\">Return to home</button>");
             out.println("<br>");
             
             out.println("<hr style=\"margin-top:0px; widht:190px; height:10px; color:green;\">");
             out.println("</div>");
            }
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(colleges.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(colleges.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(colleges.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(colleges.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
