/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.DriverManager;


/**
 *
 * @author iiit
 */
public class hospital extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
        
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con =(Connection)java.sql.DriverManager.getConnection("jdbc:mysql://localhost:3306/se_project","root","iiits123");
        Statement st=con.createStatement();
        String pat_name=request.getParameter("pat_name");
        String pat_disease=request.getParameter("pat_disesase");
        String pat_mobile=request.getParameter("pat_mobile");
        String pat_dob=request.getParameter("pat_dob");
        String pat_symptoms=request.getParameter("pat_symptoms");
        String pat_hospital=request.getParameter("pat_hospital");
        //int status=0;
       // String query="insert into hospitals values('"+pat_name+"','"+pat_disease+"','"+pat_mobile+"','"+pat_dob+"','"+pat_symptoms+"','"+pat_hospital+"');";
       //status=st.executeUpdate("insert into hospitals values('"+pat_name+"','"+pat_disease+"','"+pat_mobile+"','"+pat_dob+"','"+pat_symptoms+"','"+pat_hospital+"');");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet hospital</title>");            
            out.println("</head>");
            out.println("<body style=\" background-color:aquamarine; ;\">");
            out.println("<div style=\" margin-left:350px; height:20px; width:500px; \">");
             out.println("<hr style=\"margin-top:100px; color:green; height:10px;  \">");
             out.println("<h2 style=\"color:blue; margin-left:50px;\" ><b>Patient Name Name</b>:  <small style=\"color:black;\" >"+pat_name+"</small></h2>");
             out.println("<h2 style=\"color:blue; margin-left:50px;\" ><b>Patient disease</b>: <small style=\"color:black;\" >"+pat_disease+"</small></h2>");
             out.println("<h2 style=\"color:blue; margin-left:50px;\" ><b>Patinet mobile</b>:  <small style=\"color:black;\" >"+pat_mobile+"</small></h2>");
             out.println("<h2 style=\"color:blue; margin-left:50px;\" ><b>Patient Date of birth</b>:  <small style=\"color:black;\" >"+pat_dob+"</small></h2>");
             out.println("<h2 style=\"color:blue; margin-left:50px;\" ><b>Patient symptomss</b>:  <small style=\"color:black;\" >"+pat_symptoms+"</small></h2>");
             out.println("<h2 style=\"color:blue; margin-left:50px;\" ><b>patient hospital</b>:  <small style=\"color:black;\" >"+pat_hospital+"</small></h2>");
             out.println("<h4>You are admitted in the hospital.Take the screenshot and come to the hospital for cure the disease and <b>live life happily<b>!!....");
             out.println("<br>");
             
             out.println(" <a style=\" margin-left:200px; \" href='hospitals.html'><button style=\"height:30px;\">Return to home</button>");
             out.println("<br>");
             out.println("<hr style=\"margin-top:0px; widht:190px; height:10px; color:green;\">");
             
             out.println("</div>");
           
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(hospital.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(hospital.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(hospital.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(hospital.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
